﻿using UnityEngine;
using System.Collections;

public enum EventEnum {
    TEST1 = 1,
    TEST2,
    GameOver,
    RemoveEnemyGroup,
}