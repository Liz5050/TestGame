﻿using System;
using UnityEngine;
using System.Collections;

public class EventData : EventArgs
{

}
